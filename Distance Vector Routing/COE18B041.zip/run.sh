gnome-terminal -- python3 main.py 8000 8001 8002 8003 &
gnome-terminal -- python3 main.py 8001 8002 8003 8000 &
gnome-terminal -- python3 main.py 8002 8003 8000 8001 &
gnome-terminal -- python3 main.py 8003 8000 8001 8002